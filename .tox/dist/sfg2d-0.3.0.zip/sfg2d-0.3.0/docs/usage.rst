=====
Usage
=====

To use SFG2D in a project::

    import sfg2d
