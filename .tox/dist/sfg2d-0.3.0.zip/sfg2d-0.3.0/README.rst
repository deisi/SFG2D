===============================
SFG2D
===============================


.. image:: https://img.shields.io/pypi/v/sfg2d.svg
        :target: https://pypi.python.org/pypi/sfg2d

.. image:: https://img.shields.io/travis/deisi/sfg2d.svg
        :target: https://travis-ci.org/deisi/sfg2d

.. image:: https://readthedocs.org/projects/sfg2d/badge/?version=latest
        :target: https://sfg2d.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/deisi/sfg2d/shield.svg
     :target: https://pyup.io/repos/github/deisi/sfg2d/
     :alt: Updates


Python Toolkit for Analsys if 2d-sfg spectra


* Free software: MIT license
* Documentation: https://sfg2d.readthedocs.io.


Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

