=======
Credits
=======

Development Lead
----------------

* Malte Deiseroth <mdeiseroth88@gmail.com>

Contributors
------------

Incoperated work from many other open source projects:
- Marcos Duartes detect_peaks.py from  https://github.com/demotu/BMC
- SPE file reader
- Learned from scikit-spectra thingy
