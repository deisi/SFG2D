#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_sfg2d
----------------------------------

Tests for `sfg2d` module.
"""


import sys
import unittest
from contextlib import contextmanager
from click.testing import CliRunner

import sfg2d

import numpy as np

class TestSFG2D(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_nothing(self):
        pass

if __name__ == '__main__':
    sys.exit(unittest.main())
