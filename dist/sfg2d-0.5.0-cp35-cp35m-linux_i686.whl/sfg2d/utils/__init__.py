from .detect_peaks import detect_peaks
